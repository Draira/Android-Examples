package com.example.canvasexample;

import java.util.ArrayList;
import java.util.List;

public class Sheet {
    private int backgroundColor;
    private List<Stroke> strokes = new ArrayList<Stroke>();
    private List<Image> images = new ArrayList<Image>();

}
