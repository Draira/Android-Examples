package com.example.canvasexample;

import android.graphics.Point;

import java.util.ArrayList;
import java.util.List;

public class Stroke {
    //Guardo una lista con todos la rayita hecha
    private List<Point> points = new ArrayList<Point>();
    //La raya tiene un color
    private int color;
    //Y la raya también tiene un grosor
    private int size;

    public Stroke() {
    }

    /*Creo que tienen que ser así, porque puede cambiar al siguiente stroke*/
    public Stroke(List<Point> points, int color, int size) {
        this.points = points;
        this.color = color;
        this.size = size;
    }

    public List<Point> getPoints() {
        return points;
    }

    public void setPoints(List<Point> points) {
        this.points = points;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
