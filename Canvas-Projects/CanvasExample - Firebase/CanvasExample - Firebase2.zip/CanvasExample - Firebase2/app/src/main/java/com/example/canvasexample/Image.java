package com.example.canvasexample;

public class Image {
    private String nameRefImg;
    private int xRotateImg;
    private int yRotateImg;
    private int xPositionImg;
    private int yPositionImg;
    private int xDimensionImg;
    private int yDimensionImg;

    public Image() {
    }

    public Image(String nameRefImg, int xRotateImg, int yRotateImg, int xPositionImg, int yPositionImg) {
        this.nameRefImg = nameRefImg;
        this.xRotateImg = xRotateImg;
        this.yRotateImg = yRotateImg;
        this.xPositionImg = xPositionImg;
        this.yPositionImg = yPositionImg;
    }

    public int getxRotateImg() {
        return xRotateImg;
    }

    public void setxRotateImg(int xRotateImg) {
        this.xRotateImg = xRotateImg;
    }

    public int getyRotateImg() {
        return yRotateImg;
    }

    public void setyRotateImg(int yRotateImg) {
        this.yRotateImg = yRotateImg;
    }

    public int getxPositionImg() {
        return xPositionImg;
    }

    public void setxPositionImg(int xPositionImg) {
        this.xPositionImg = xPositionImg;
    }

    public int getyPositionImg() {
        return yPositionImg;
    }

    public void setyPositionImg(int yPositionImg) {
        this.yPositionImg = yPositionImg;
    }

    public int getxDimensionImg() {
        return xDimensionImg;
    }

    public void setxDimensionImg(int xDimensionImg) {
        this.xDimensionImg = xDimensionImg;
    }

    public int getyDimensionImg() {
        return yDimensionImg;
    }

    public void setyDimensionImg(int yDimensionImg) {
        this.yDimensionImg = yDimensionImg;
    }
}
